#ifndef TIMER_H
#define TIMER_H

#include <stdio.h>
#include <stdlib.h>
#include <inttypes.h>

#define GHZ 1500000000000000

uint64_t tick(void);

#endif
