#ifndef __TIME_H__
#define __TIME_H__

#include <stdint.h>
#include <inttypes.h>

uint64_t tick(void);

#endif
